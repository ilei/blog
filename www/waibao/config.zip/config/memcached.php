<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config = array(
    'host' => '127.0.0.1',
    'port' => '11211',
);

/* End of file auth.php */
/* Location: ./application/config/auth.php */
