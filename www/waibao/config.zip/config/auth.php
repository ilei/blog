<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config = array('no_login' => array('istratoradmin/user/login'));
/* End of file auth.php */
/* Location: ./application/config/auth.php */
