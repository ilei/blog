<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config = array(
    'last_release' => '20150315'
);
